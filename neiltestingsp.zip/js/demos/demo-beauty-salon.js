/*
Name:           Demo Beauty Salon
Written by:     Okler Themes - (http://www.okler.net)
Theme Version:  9.7.0
*/

(function( $ ) {
	
	'use strict';

	

}).apply( this, [ jQuery ]);
